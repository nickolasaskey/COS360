package com.projecttwo.app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import android.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.projecttwo.app.databinding.ActivityMainBinding
import com.projecttwo.app.databinding.CalendarScreenBinding
import com.projecttwo.app.databinding.EventBinding
import com.projecttwo.app.databinding.TextCommunicationBinding

class MainActivity : AppCompatActivity() {

    private lateinit var eventTrackerAdapter: EventTrackerAdapter
    private lateinit var calendarScreen: CalendarScreenBinding
    private lateinit var eventScreen: EventBinding
    private lateinit var loginScreen: ActivityMainBinding
    private lateinit var signupScreen: TextCommunicationBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        calendarScreen = CalendarScreenBinding.inflate(layoutInflater)
        val view = calendarScreen.root
        setContentView(R.layout.activity_main)

        calendarScreen.eventList.adapter = eventTrackerAdapter
        calendarScreen.eventList.layoutManager = LinearLayoutManager(this)

        loginScreen.signUpButton.setOnClickListener {
            setContentView(R.layout.text_communication)
        }
        loginScreen.loginSubmit.setOnClickListener {
            val email = loginScreen.loginEmail.text.toString()
            val password = loginScreen.loginPassword.text.toString()
            if(email.isNotEmpty()) {
                if(password.isNotEmpty()) {
                    setContentView(R.layout.calendar_screen)
                }
            }
        }

        signupScreen.signupSubmit.setOnClickListener {
            val email = signupScreen.signupEmail.text.toString()
            val password = signupScreen.signupPassword.text.toString()
            val first = signupScreen.signupFirst.text.toString()
            val last = signupScreen.signupLast.text.toString()
            val verify = signupScreen.verifyPassword.text.toString()
            if(first.isNotEmpty()) {
                if(last.isNotEmpty()) {
                    if(email.isNotEmpty()) {
                        if(password.isNotEmpty()) {
                            if(password.equals(verify)) {
                                setContentView(R.layout.calendar_screen)
                            }
                        }
                    }
                }
            }
        }

        calendarScreen.addEvent.setOnClickListener {
            val newEventTitle = calendarScreen.setEventName.text.toString()
            val newEventDate = calendarScreen.setDate.text.toString()
            val newEventTime = calendarScreen.setTime.text.toString()
            if (newEventTitle.isNotEmpty()) {
                if (newEventDate.isNotEmpty()) {
                    if (newEventTime.isNotEmpty()) {
                            val Event = Events(newEventTitle, newEventDate, newEventTime)
                            eventTrackerAdapter.addEvent(Event)
                        }

                }

            }
        }
        eventScreen.deleteEvent.setOnClickListener {
            eventTrackerAdapter.deleteCurrentEvent(0)
        }

    }

}
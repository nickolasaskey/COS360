package com.projecttwo.app

data class Events(
    val title: String,
    val date: String,
    val time: String
)
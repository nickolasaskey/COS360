package com.projecttwo.app

import android.database.DataSetObserver
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.projecttwo.app.databinding.CalendarScreenBinding
import com.projecttwo.app.databinding.EventBinding

class EventTrackerAdapter(
    private val events: MutableList<Events>

) : RecyclerView.Adapter<EventTrackerAdapter.EventViewHolder>() {

    class EventViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    private lateinit var binding: EventBinding

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        return EventViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.event,
                parent,
                false
            )
        )
    }

    fun addEvent(newEvent: Events) {
        events.add(newEvent)
        notifyItemInserted(events.size - 1)
    }

    fun deleteCurrentEvent(position: Int) {
        events.removeAt(position)
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        val curEvent = events[position]
        holder.itemView.apply {
            binding.tEventTitle.text = curEvent.title
            binding.tEventDate.text = curEvent.date
            binding.tEventTime.text = curEvent.time
        }
    }

    override fun getItemCount(): Int {
        return events.size
    }
}